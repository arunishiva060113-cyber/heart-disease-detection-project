


// Simple MLP with one hidden layer
class MLP {
    inputSize: number;
    hiddenSize: number;
    outputSize: number;
    w1: number[][];
    b1: number[];
    w2: number[];
    b2: number;

    constructor(inputSize: number, hiddenSize: number) {
        this.inputSize = inputSize;
        this.hiddenSize = hiddenSize;
        this.outputSize = 1;
        // Xavier initialization
        this.w1 = Array.from({ length: hiddenSize }, () => Array.from({ length: inputSize }, () => Math.random() * 2 - 1));
        this.b1 = Array(hiddenSize).fill(0);
        this.w2 = Array.from({ length: hiddenSize }, () => Math.random() * 2 - 1);
        this.b2 = 0;
    }

    sigmoid(x: number): number {
        return 1 / (1 + Math.exp(-x));
    }

    dsigmoid(y: number): number {
        return y * (1 - y);
    }

    // Forward pass
    predict(inputs: number[]): number {
        // Hidden layer
        const h = this.w1.map((w, i) => this.sigmoid(w.reduce((sum, wi, j) => sum + wi * inputs[j], this.b1[i])));
        // Output layer
        const o = this.sigmoid(h.reduce((sum, hi, i) => sum + hi * this.w2[i], this.b2));
        return o;
    }

    // Train with one sample (SGD, backprop)
    train(inputs: number[], label: number, lr: number) {
        // Forward
        const h_raw = this.w1.map((w, i) => w.reduce((sum, wi, j) => sum + wi * inputs[j], this.b1[i]));
        const h = h_raw.map(this.sigmoid);
        const o_raw = h.reduce((sum, hi, i) => sum + hi * this.w2[i], this.b2);
        const o = this.sigmoid(o_raw);

        // Backward
        const error = label - o;
        const d_o = error * this.dsigmoid(o);

        // Gradients for w2, b2
        for (let i = 0; i < this.hiddenSize; i++) {
            this.w2[i] += lr * d_o * h[i];
        }
        this.b2 += lr * d_o;

        // Gradients for w1, b1
        for (let i = 0; i < this.hiddenSize; i++) {
            const d_h = d_o * this.w2[i] * this.dsigmoid(h[i]);
            for (let j = 0; j < this.inputSize; j++) {
                this.w1[i][j] += lr * d_h * inputs[j];
            }
            this.b1[i] += lr * d_h;
        }
    }
}


import * as fs from 'fs';
import { parse } from 'csv-parse/sync';

// Load and parse CSV
const csvData = fs.readFileSync('heart.csv', 'utf-8');
const records: Record<string, string>[] = parse(csvData, {
    columns: true,
    skip_empty_lines: true
});


// Use more features for better accuracy
const featureNames = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal'];
const labelName = 'target';



// Feature normalization (min-max scaling)
function normalizeFeatures(data: number[][]): number[][] {
    const mins = data[0].map((_, i) => Math.min(...data.map(row => row[i])));
    const maxs = data[0].map((_, i) => Math.max(...data.map(row => row[i])));
    return data.map(row => row.map((v, i) => (maxs[i] - mins[i] === 0 ? 0 : (v - mins[i]) / (maxs[i] - mins[i]))));
}

// Convert all data to features/labels
const rawFeatures = records.map(row => featureNames.map(f => parseFloat(row[f])));
const normFeatures = normalizeFeatures(rawFeatures);
const data = records.map((row, idx) => ({
    features: normFeatures[idx],
    label: parseInt(row[labelName])
}));

const mlp = new MLP(featureNames.length, 24); // 24 hidden units

// Training parameters
const epochs = 1000;
const lr = 0.1;

// Shuffle function
function shuffle<T>(array: T[]): T[] {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// Training loop
for (let epoch = 0; epoch < epochs; epoch++) {
    shuffle(data);
    for (const sample of data) {
        mlp.train(sample.features, sample.label, lr);
    }
    // Optionally print progress
    if ((epoch + 1) % 200 === 0) {
        let correct = 0;
        for (const sample of data) {
            const pred = mlp.predict(sample.features) > 0.5 ? 1 : 0;
            if (pred === sample.label) correct++;
        }
        const acc = (correct / data.length) * 100;
        console.log(`Epoch ${epoch + 1}: Accuracy = ${acc.toFixed(2)}%`);
    }
}

// Evaluate accuracy
let correct = 0;
let total = 0;
for (const sample of data) {
    const pred = mlp.predict(sample.features) > 0.5 ? 1 : 0;
    if (pred === sample.label) correct++;
    total++;
}

const accuracy = (correct / total) * 100;
console.log(`Accuracy on heart.csv (MLP, 1 hidden layer): ${accuracy.toFixed(2)}%`);

// Save model parameters to disk
const modelParams = {
    w1: mlp.w1,
    b1: mlp.b1,
    w2: mlp.w2,
    b2: mlp.b2,
    featureNames
};
fs.writeFileSync('mlp_model.json', JSON.stringify(modelParams, null, 2));
console.log('Trained model saved to mlp_model.json');
